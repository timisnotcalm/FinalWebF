package com.example.spring.service;

import com.example.spring.DAO.PhoneDAO;
import com.example.spring.model.Phone;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PhoneService {
    @Autowired
    private PhoneDAO phoneDAO;

    public List<Phone> findAllPhones() {
        return phoneDAO.findAll();
    }

    public Optional<Phone> findPhoneById(Long id) {
        return phoneDAO.findById(id);
    }

    public Phone findByTitle(String title) {
        return phoneDAO.findPhoneByTitle(title);
    }

    public Phone findPhoneByPrice(Double price) {
        return phoneDAO.findPhoneByPrice(price);
    }

    public void createPhone(Phone phone) {
        phoneDAO.save(phone);
    }

    public void updatePhone(Long id, Phone phone) {
        Phone phoneDb = phoneDAO.findById(id).orElse(null);
        if (phoneDb != null) {
            phoneDb.setDescription(phone.getDescription());
            phoneDb.setPrice(phone.getPrice());
            phoneDAO.saveAndFlush(phoneDb);
        }
    }

    public void deletePhone(Long id) {
        phoneDAO.deleteById(id);
    }
}
