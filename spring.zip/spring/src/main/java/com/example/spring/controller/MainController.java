package com.example.spring.controller;

import com.example.spring.model.Phone;
import com.example.spring.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("store")
public class MainController {
    @Autowired
    PhoneController phoneController;

    @Autowired
    UserController userController;

    @GetMapping("")
    public String index() {
        return "index";
    }

    @GetMapping("/home")
    public String home() {
        return "home";
    }

    @GetMapping("/phones")
    public String phones(Model model) {
        model.addAttribute("phones", phoneController.findAllPhones());
        return "phones";
    }

    @GetMapping("/createPhone")
    public String createPhone() {
        return "createPhone";
    }

    @PostMapping("/createPhone")
    public String createPhone(Phone phone) {
        phoneController.createPhone(phone);
        return "redirect:/store/phones";
    }

    @PostMapping("/deletePhone")
    private String deletePhone(Long id){
        phoneController.deletePhone(id);
        return "redirect:/store/phones";
    }

//    @GetMapping("/updateUser")
//    public String updateUser(Model model, String nickname) {
//        model.addAttribute("user", userController.findByNickname(nickname));
//        return "updateUserPage";
//    }
//
//    @PostMapping("/updateUserMethod")
//    private String updateUser(Long id, User user){
//        userController.updateUser(id, user);
//        return "redirect:/home/admin";
//    }

    @PostMapping("/deleteUser")
    private String deleteUser(Long id){
        userController.deleteUser(id);
        return "redirect:/store/admin";
    }

    @GetMapping("/admin")
    public String users(Model model) {
        model.addAttribute("users", userController.findAllUsers());
        return "admin";
    }

    @GetMapping("/profile")
    public String profile(Model model) {
        model.addAttribute("users", userController.findAllUsers());
        return "profile";
    }

    @GetMapping("/signin")
    public String signIn() {
        return "signin";
    }

    @GetMapping("/homeAdmin")
    public String signInAdmin() {
        return "homeAdmin";
    }

    @PostMapping("/signin")
    public String signIn(Model model, String nickname) {
        User user = userController.findByNickname(nickname);
        if (user.isAccountNonExpired() && user.getNickname().equals("admin") && user.getPassword().equals("admin")) {
            model.addAttribute("nickname", user);
            return "redirect:/store/homeAdmin";
        }
        else if (user.isAccountNonExpired() && !user.getNickname().equals("admin")) {
            model.addAttribute("nickname", user);
            return "redirect:/store/home";
        }
        else {
            return "redirect:/store";
        }
    }

    @GetMapping("/signup")
    public String signUp() {
        return "signup";
    }

    @PostMapping("/signup")
    public String signUp(User user) {
        userController.createUser(user);
        return "redirect:/store/home";
    }

    @GetMapping("/logout")
    public String logout() {
        return "redirect:/";
    }
}
