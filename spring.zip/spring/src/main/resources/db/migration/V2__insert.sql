insert into users(id, nickname, email, password, cash)
values(1, 'alish', 'alish@gmail.com', 'alish1234', 2000);
insert into users(id, nickname, email, password, cash)
values(2, 'karina', 'karina@gmail.com', '1234', 10000);
insert into users(id, nickname, email, password, cash)
values(3, 'alibi', 'alibi@gmail.com', '0000', 5000);
insert into users(id, nickname, email, password, cash)
values(4, 'admin', 'admin@gmail.com', 'admin', 50000);