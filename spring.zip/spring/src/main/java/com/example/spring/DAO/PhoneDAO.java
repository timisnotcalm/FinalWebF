package com.example.spring.DAO;

import com.example.spring.model.Phone;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PhoneDAO extends JpaRepository<Phone, Long> {
    Phone findPhoneByTitle(String title);
    Phone findPhoneByPrice(Double price);
}
