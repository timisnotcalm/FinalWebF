package com.example.spring.controller;

import com.example.spring.model.Phone;
import com.example.spring.service.PhoneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/phones")
public class PhoneController {
    @Autowired
    private PhoneService phoneService;

    @GetMapping("")
    public List<Phone> findAllPhones() {
        return phoneService.findAllPhones();
    }

    @GetMapping("/{id}")
    public Optional<Phone> findPhoneById(@PathVariable Long id) {
        return phoneService.findPhoneById(id);
    }

    @GetMapping("/title/{title}")
    public Phone findByTitle(@PathVariable String title) {
        return phoneService.findByTitle(title);
    }

    @GetMapping("/price/{price}")
    public Phone findPhoneByPrice(@PathVariable Double price) {
        return phoneService.findPhoneByPrice(price);
    }

    @PostMapping("/create")
    public void createPhone(@RequestBody Phone phone) {
        phoneService.createPhone(phone);
    }

    @PutMapping("/{id}")
    public void updatePhone(@PathVariable Long id, @RequestBody Phone phone) {
        phoneService.updatePhone(id, phone);
    }

    @DeleteMapping("/{id}")
    public void deletePhone(@PathVariable Long id) {
        phoneService.deletePhone(id);
    }
}
