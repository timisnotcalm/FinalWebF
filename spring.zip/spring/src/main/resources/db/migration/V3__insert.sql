insert into games(id, title, description, price)
values(1, 'CSGO', 'online shooter', 5000);
insert into games(id, title, description, price)
values(2, 'Dota 2', 'online MMO', 2000);